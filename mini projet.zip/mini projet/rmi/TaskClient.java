import java.rmi.Naming;
import java.util.List;

// Client pour utiliser le service de gestion de tâches
public class TaskClient {
    public static void main(String[] args) {
        try {
            TaskService taskService = (TaskService) Naming.lookup("//localhost/TaskService");
            
            // Ajout d'une tâche
            taskService.addTask("Faire les courses");
            
            // Suppression d'une tâche
            taskService.removeTask("Faire le ménage");
            
            // Récupération des tâches
            List<String> tasks = taskService.getTasks();
            System.out.println("Liste des tâches : " + tasks);
        } catch (Exception e) {
            System.err.println("Erreur du client : " + e.toString());
            e.printStackTrace();
        }
    }
}


