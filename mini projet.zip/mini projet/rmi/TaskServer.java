package rmi;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

// Interface du service de gestion de tâches
interface TaskService extends java.rmi.Remote {
    void addTask(String task) throws RemoteException;
    void removeTask(String task) throws RemoteException;
    List<String> getTasks() throws RemoteException;
}

// Implémentation du service de gestion de tâches
public class TaskServer extends UnicastRemoteObject implements TaskService {
    private List<String> tasks;

    protected TaskServer() throws RemoteException {
        super();
        tasks = new ArrayList<>();
    }

    public void addTask(String task) {
        tasks.add(task);
        System.out.println("Tâche ajoutée : " + task);
    }

    public void removeTask(String task) {
        if (tasks.remove(task)) {
            System.out.println("Tâche supprimée : " + task);
        } else {
            System.out.println("Tâche non trouvée : " + task);
        }
    }

    public List<String> getTasks() {
        return tasks;
    }

    public static void main(String[] args) {
        try {
            TaskServer obj = new TaskServer();
            LocateRegistry.createRegistry(1099);
            Naming.rebind("//localhost/TaskService", obj);
            System.out.println("Serveur prêt !");
        } catch (Exception e) {
            System.err.println("Erreur du serveur : " + e.toString());
            e.printStackTrace();
        }
    }
}

