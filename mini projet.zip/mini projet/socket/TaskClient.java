package socket;

import java.io.*;
import java.net.*;

// Client pour utiliser le service de gestion de tâches via des sockets
public class TaskClient {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
        try (
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))
        ) {
            String userInputLine;
            while ((userInputLine = userInput.readLine()) != null) {
                out.println(userInputLine);
                if (userInputLine.equals("quit")) {
                    break;
                }
                String response = in.readLine();
                System.out.println("Réponse du serveur : " + response);
            }
        } catch (UnknownHostException e) {
            System.err.println("Hôte inconnu : " + SERVER_ADDRESS);
        } catch (IOException e) {
            System.err.println("Erreur lors de la communication avec le serveur : " + e.getMessage());
        }
    }
}

