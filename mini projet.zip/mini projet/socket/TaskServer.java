package socket;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

// Serveur pour le service de gestion de tâches utilisant des sockets
public class TaskServer {
    private static final int PORT = 12345;
    private static List<String> tasks = new ArrayList<>();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serveur prêt !");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nouvelle connexion : " + clientSocket);
                new ServerThread(clientSocket).start();
            }
        } catch (IOException e) {
            System.err.println("Erreur du serveur : " + e.getMessage());
        }
    }

    // Classe interne pour gérer les connexions clients
    private static class ServerThread extends Thread {
        private Socket clientSocket;

        public ServerThread(Socket socket) {
            this.clientSocket = socket;
        }

        public void run() {
            try (
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))
            ) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    if (inputLine.equals("getTasks")) {
                        out.println(tasks);
                    } else if (inputLine.startsWith("addTask")) {
                        String task = inputLine.substring(8);
                        tasks.add(task);
                        System.out.println("Tâche ajoutée : " + task);
                    } else if (inputLine.startsWith("removeTask")) {
                        String task = inputLine.substring(11);
                        if (tasks.remove(task)) {
                            System.out.println("Tâche supprimée : " + task);
                        } else {
                            System.out.println("Tâche non trouvée : " + task);
                        }
                    }
                }
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Erreur lors de la communication avec le client : " + e.getMessage());
            }
        }
    }
}
